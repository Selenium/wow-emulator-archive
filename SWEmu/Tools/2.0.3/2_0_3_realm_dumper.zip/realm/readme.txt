copyright by author. 
This is for personal purpuses only. Sharing and using of this software is strictly forbiden.

Almoust general purpuse network dumper will listen to 3724 port number and log TCP and UDP packets to file
Autput format :

========================================
Direction : Client -> Server
Length : 1
Opcode : 00 = CMSG_CMD_AUTH_LOGON_CHALLENGE
Data : 
FF
========================================

where :
length = the length of data part of a network packet without 1 byte
opcode = first byte of the packet
data = the data of a network packet without first byte
