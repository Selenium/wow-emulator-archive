this will deflate the compressed packets in a dump file.

usage ex : deflater_dump_file.exe dump_1166833947.txt

why not deflate whyle logging ? because who knows what where when will be used. Just think as modularising process