The content of this zip is private property. The use of the files a strictly forbiden to anybody but the autor

First time you run dumper, clear wdb folder !! (avoid to have missing templates at parsing)

1) copy "loader.exe" and "UDP.dll" to wow dir
2) start wow (2.0.x client)
3) login to wow (this way your personal info is not logged)
4) on char selection screen switch context and start "loader.exe" (ALT+TAB to switch context)
5) start playing
6) zip "dump_*.txt" files and send it to somebody who has a parser 

Output format :

=================================
Direction : Server -> Client
Length : 3
Opcode : 003A = SMSG_CHAR_CREATE
Data : 
2E 7A 06 
=================================

Length = the length of data without opcode and length. Total packet length is length + 4 bytes
opcode = 2 bytes 
data = the remaining packet (without the first 4 bytes)

